# 研究續接（2026-11-14，S20–S23全部完成）

## 現在狀態

沒有執行中的實驗。最佳仍為cheese-robust（research/bin/learned-robust，50k生成節點）。
原cheese-quality／learned-fast、S11source checkpoint及manifest所有hash核對未變。
S20–S23新增601局全部完成及完整回放，336個不同seed ID（開發seed重用，不能
當601個獨立樣本），8033.862064 CPU秒。見results/s20-s23-completion.json。

## 最新結果

S22正式75300..75363三版各64/64：
- learned-fast 198.671875塊；learned-robust 196.21875；Hold候選196.546875。
- 候選−robust +0.328125，95%[-1.515625,2.15625]，27勝6平31敗。
- 候選−legacy -2.125，95%[-4.25,0]。雙控制嚴格區間門檻失敗，**不升級**。
- 192回放、逐步metadata一致性與50k預算檢查全通過。
- robust−legacy -2.453125，95%[-4.171875,-0.671875]，再次支持既有策略。
- 不擴樣本，不合併開發挽救；正式前已約定僅通過才跑200k，因此未啟動200k。

## 候選由來／保留的失敗實驗

1. S20：新資料76400..76559，160局5k來源，全回放；128訓練76400..76527，
   32預測驗證76528..76559。公開Hold×5盤面特徵，固定ridge10，類型均值零。
   整局成本標籤驗證MSE40.28499→40.32575，未接入策略。
2. S21：同128訓練，固定7步＋凍結估值標籤；新76600..76631預測驗證32局。
   MSE2.735080→2.722706，區間跨零。沒有步數／正則掃描。
   robust-hold-context = cheese-robust + hold-context + preserve-hold。
   32dev198.15625 vs robust197.1875，拒絕。68測試，32回放通過。
3. S22：相同權重、原本耗盡Hold終點；robust-hold-order = cheese-robust
   +hold-context，影響中間估值及parent_f，不能稱純排序。
   dev76000..76031：195.96875 vs197.1875；新驗證76200..76247：196.6875
   vs197.833333，皆CI跨零但通過預設平均篩選；正式未重現，詳見上方。
4. S23：精確cache，robust-hold-cached = cheese-robust + hold-context-cache。
   每analysis盤面cache七種Hold修正，69測試；三盤完整inputs/ds/搜尋計數一致，
   6回放。CPU22.628→20.306秒，RSS26209→30996KiB；僅小型成本試驗。
   沒有減少方塊數，未替換S22正式執行檔，也不作推薦profile。

## 程式與重現

- CONTEXT_REPORT.md、PROTOCOL.md記錄完整假設／門檻／結果，s22-outcomes.svg圖。
- fit_hold.py：不帶參數為S20，--td7為S21；權重不重新選擇。
- 模型blockfish-engine/src/ai/hold_weights.rs；s21-fit-dependencies.json資料hash。
- State.held_color()只回實際Hold，空Hold不能把next().1當Hold。
- hold-context不隱含preserve-hold；S21profile明確加入，S22不加入。
- audit_context_cache.py檢查S23完全等價；diagnose_hold_coverage.py查訓練覆蓋。
- decide_cohort.py含配對seed/hash/config/每步預算/trace一致性門檻；replay_audit.py回放。
- checkpoints/s22-candidate-20261114-source.tar.gz已離線還原建置，二進位SHA與
  凍結S22完全相同（results/s22-restore-check.json）；當時是候選快照，現在正式失敗。
- checkpoints/s23-20261114-source.tar.gz保存本輪完成源碼與腳本；manifest含結果hash。

## 下一步與禁止重用

停止這組Hold殘差的係數／正則／步數／邊界微調。觀察性實際遊戲回報與
搜尋葉分布不同、七步標籤繼承凍結估值偏差，均是限制，尚未證明唯一失敗原因。
可研究少量候選的條件rollout或搜尋葉成本標籤；沿用原SRS/Hold/合法落點。
線上抽樣只能依公開七袋歷史，不可複製真實隱藏RNG後拿來評分。
未實作這些後續方法，不宣稱改善。仍優先完整100L方塊數，不以MSE或速度代替。

76200策略驗證、75300正式已開封；76400..76559與76600..76631已用資料學習。
76000..76031反覆開發，不是泛化證據。未來不同假設可用76700..76747新驗證、
75400..75463新正式，目前尚未使用。S11/S18等先前保留集也不可調參。
舊續接全文CONTINUE_HISTORY_20261114.md僅供歷史，若衝突以本檔及各lock為準。
