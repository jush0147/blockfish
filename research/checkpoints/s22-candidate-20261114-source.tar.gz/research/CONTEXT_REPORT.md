# S20/S21：Hold 條件估值與標籤噪音

延續 S19 的表示限制，檢查只有盤面特徵的估值是否需要 Hold 條件修正。
不再掃描搜尋邊界或增加節點預算，可靠基準 cheese-robust 保持不變。

## 資料與固定模型

`BoardSample` 新增公開的 `hold: Option<char>`，來源是當下 Snapshot，
不讀未來方塊或 RNG。新 `context-source` 使用原 cheese-quality；3盤
完整操作／消除序列與凍結 learned-fast 一致。76400..76559 共160個新
種子，以5k節點來源策略完整玩100L，全部完成並由凍結程式回放通過。
前128盤76400..76527訓練，後32盤76528..76559檢查預測。

模型是七種 Hold 的中心化 one-hot，與既有盤面特徵
`[bias,height,piece_estimate,i_dependencies,wells]` 的交互項。每盤總權重
相同；RMS尺度只從訓練資料估計；ridge固定10，沒有參數掃描。空 Hold
修正固定零，七種類型的修正平均固定零。原盤面權重不動。這不能消除
策略選擇 Hold 所造成的觀察性混淆，不能解讀成更換 Hold 的因果效果。

排除尚未可見垃圾少於20行的收尾樣本；使用訓練盤平均每行成本2.027109375
調整不可見垃圾。隱藏未來只出現在離線回報標籤，模型輸入只有盤面及 Hold。
18,995個訓練狀態仍只來自128個獨立遊戲；信賴區間按遊戲重抽樣。

## S20：整局回報

標籤為實際剩餘方塊數減去尚未可見垃圾的平均成本。擬合相對凍結盤面
估值的殘差，不重新訓練盤面係數。

|集合|遊戲數|原MSE|修正MSE|
|---|---:|---:|---:|
|訓練|128|38.312537|38.176328|
|獨立預測驗證|32|40.284986|40.325747|

驗證差+0.040761，95%遊戲bootstrap[-0.151956,0.245482]。
**未通過預先設定的平均預測門檻；不接入策略。**

## S21：固定七步標籤

為檢查長期回報噪音，固定使用七步成本加七步後的凍結盤面估值，按
期間可見垃圾變化作同樣調整。七步由七袋長度事先決定，沒有步數掃描。
使用相同128盤訓練，但另收全新76600..76631的32盤作預測驗證，全部
完成且回放通過。沒有再次使用S20已看過的驗證集調整模型。

|集合|遊戲數|原MSE|修正MSE|
|---|---:|---:|---:|
|訓練|128|2.770994|2.695545|
|新預測驗證|32|2.735080|2.722706|

驗證差−0.012374，95%遊戲bootstrap[-0.041443,0.017138]。僅通過預設的
平均門檻，區間跨零。兩輪標籤不同，不能把MSE絕對值下降當成策略收益。
凍結權重後進入完整100L開發試驗；預測誤差本身不作升級依據。

## 實作與適用限制

新增 optional `hold-context`，與 cheese-robust、preserve-hold 明確組合為
`robust-hold-context`。每次估值在原盤面cache之外加上公開Hold修正，
避免同盤面不同Hold污染cache。`State::held_color()`區分真正Hold與
空Hold時可交換的第二預覽。68項測試通過，包括空Hold、預覽耗盡後仍
保有Hold、七種修正平均為零。推論分數以既有十分之一方塊單位量化。

這仍有訓練／搜尋分布差異：訓練是真實current+5預覽的策略狀態，搜尋
葉可能只剩Hold。實際效果必須由完整對局決定。開發固定76000..76031、
50k生成節點，同時比較凍結robust與S19保留Hold版本；比較CPU僅描述，
對照是較早批次。候選必須平均勝過兩者才進新策略驗證集。

## 重現

```sh
source /workspace/.blockfish-env/activate.sh
python3 research/build.py context-source
python3 research/bench.py --binary research/bin/context-source --configs 5/5,10,10,10 --start 76400 --count 160 --jobs 4 --collect-features --out research/results/s20-data.jsonl
python3 research/fit_hold.py
python3 research/bench.py --binary research/bin/context-source --configs 5/5,10,10,10 --start 76600 --count 32 --jobs 4 --collect-features --out research/results/s21-data.jsonl
python3 research/fit_hold.py --td7
python3 research/build.py robust-hold-context
cargo test --locked -p blockfish --lib --no-default-features --features race,cheese-robust,hold-context,preserve-hold
python3 research/bench.py --binary research/bin/robust-hold-context --configs 50/5,10,10,10 --start 76000 --count 32 --jobs 4 --out research/results/s21-dev.jsonl
python3 research/decide_cohort.py --lock research/results/s21-dev-lock.json --inputs research/results/s16-control-dev.jsonl research/results/s19-dev.jsonl research/results/s21-dev.jsonl --out-prefix research/results/s21-dev --gate mean
```

## S21完整對局結果

32/32完成，候選198.15625塊、凍結robust197.1875、S19保留Hold200.8125。
相對robust差+0.96875，95%配對區間[-1.875,3.90625]，13勝3平16敗。
相對S19差−2.65625，區間[-5.34375,0.0625]，20勝2平10敗。
**沒有勝過可靠基準，拒絕升級。** 不能因勝過較弱的S19而宣稱改進。
32份回放全部通過。候選CPU25.813秒／局，對照15.666／16.883秒／局；
額外特徵計算有成本，未投入加速，因尚未證明方塊數收益。

## S22：相同權重、原本搜尋終點

另作固定權重的結構消融：保留原本放完已知Hold的終點，只加Hold條件
修正，profile為robust-hold-order。hold-context不再隱含preserve-hold依賴；
S21profile明確指定兩者，因此S21凍結二進位和行為不變。新profile的
68項測試通過；s22-dev-lock記錄與S21完全相同的權重hash。

正常的耗盡預覽終點已沒有Hold，因此作用主要在中間節點排序和父節點
平滑分數。不能稱為純搜尋排序消融，因parent_f也參與終點rating。
相同76000..76031、50k；不得看結果後調權重。需勝過原robust與S21才
進新策略驗證。單獨改變葉邊界已失敗，不再把較弱對照作升級標準。
