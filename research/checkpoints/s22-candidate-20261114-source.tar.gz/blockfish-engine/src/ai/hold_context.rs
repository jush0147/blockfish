//! Experimental S21 residual. Only public held type and board are inputs.
use super::{state::State, value_features::board_features};
use crate::Color;
include!("hold_weights.rs");
const TYPES: &str = "IJLOSTZ";
const INDICES: [usize; 5] = [0, 1, 2, 3, 11];

fn correction(features: &[f64; 14], hold: Option<Color>) -> f64 {
    match hold.and_then(|color| TYPES.chars().position(|c| c == color.as_char())) {
        None => 0.0,
        Some(i) => INDICES.iter().zip(HOLD_WEIGHTS[i].iter())
            .map(|(&j, &w)| features[j] * w).sum(),
    }
}

pub(super) fn adjust(score: i64, state: &State) -> i64 {
    let hold = state.held_color();
    if hold.is_none() { return score; }
    let delta = correction(&board_features(state.matrix()), hold);
    (score as f64 + delta * 10.0).max(0.0).round() as i64
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{ai::Snapshot, BasicMatrix};
    #[test]
    fn empty_hold_is_not_the_second_preview() {
        let state: State = Snapshot { matrix: BasicMatrix::with_cols(10), hold: None,
            queue: "IJ".chars().map(Color::n).collect() }.into();
        assert_eq!(state.next().1, Some(Color::n('J')));
        assert_eq!(state.held_color(), None);
        assert_eq!(adjust(120, &state), 120);
    }
    #[test]
    fn held_piece_remains_available_when_preview_is_exhausted() {
        let state: State = Snapshot { matrix: BasicMatrix::with_cols(10),
            hold: Some(Color::n('I')), queue: vec![] }.into();
        assert_eq!(state.is_terminal(), cfg!(feature = "preserve-hold"));
        assert_eq!(state.held_color(), Some(Color::n('I')));
    }
    #[test]
    fn type_corrections_are_centered_for_every_feature() {
        for j in 0..14 {
            let mut features = [0.;14]; features[j] = 1.;
            let total: f64 = TYPES.chars().map(|c| correction(&features, Some(Color::n(c)))).sum();
            assert!(total.abs() < 1e-10);
            assert_eq!(correction(&features, None), 0.0);
        }
    }
}
