# 續接：S27–S28完成（2026-11-15）

## 當前狀態

沒有執行中的實驗。cheese-robust仍為唯一保留的已驗證最佳策略，
research/bin/learned-robust與S11/S26所有manifest項目未變；本輪不升級。
新checkpoint：checkpoints/s28-20261115-source.tar.gz及manifest。
43局實際完整100L全部完成並回放（32候選、3observer、8新訓練來源）。
另有64條條件完整延續與64條短期延續，均已回放；只來自8個來源，
不是64個新的獨立策略測試。成本882.882487+507.88818 CPU秒。
總結results/s27-s28-completion.json；腳本、二進位、原始操作與hash均保留。

## 綜合判斷

SYNTHESIS_S27.md先區分選模偏差、標籤/使用分布錯配、有限預算排擠、
模擬跟隨策略與端點偏差。共同代理目標問題不是已唯一識別的共同根因。
不預設B*已到極限，也不認為增加模型複雜度能修復標籤不確定性。
S28表明，即使跟隨策略一致，小樣本完整偏好與短期估值仍不穩定；
但這只是8個中盤來源的診斷，不能外推為所有rollout方法無效。

## S27：保留根身份的轉置合併

root-dag依完整State/depth/root記錄首次展開，跳過重複非終點子樹。
非終點parent_f不影響後代（succ覆蓋為當前f）；終點評分/robust4不改。
重複節點本身仍收生成費，所有實際生成≤50k，不接觸未知資訊。
68tests，小棋盤完整窮舉每根評分相同及合法路徑；3盤observer同操作/計數。
開發76800..31：197.28125 vs196.21875，32/32；差+1.0625，
95%[-1.71875,3.8125]，14勝4平14敗。未過平均門檻，不進驗證。
CPU21.93050 vs歷史控制16.11831秒/局；不是速度改善。
平均每步424.47重複被合併，唯一展開1515.20，但不等於品質改善。
停止轉置範圍/key掃描，不把省去冗餘當成降低方塊數的證據。

## S28：固定規模的公開條件標籤診斷

新訓練76900..76907，固定第100顆後公開狀態；每來源最多兩根、四共同世界。
strong50k執行至100L（上限400落子）；同軌跡第4步端點；weak1040四步端點。
真正來源seed僅用於重播過去100步，不把未來/RNG傳入假想策略。
8/8 base動作與frozen源局第101動作相同。64/64完整延續完成，weak截斷0。
全部公共輸入、FNV、操作、成本與逐次生成預算驗證通過。
完整四世界均值6非平手、2平手；強短/弱短各同意3/6非平手來源。
前後兩組世界偏好：2同向、2反向、3單側平手、1雙側平手。
不是可靠的accuracy估計，也不能把四世界均值當真值。
316406444總生成記帳、507.88818CPU秒、最高RSS54500KiB。
不擴pilot、不擬合新模型、不部署full-rollout作50k候選。
PUBLIC_LABEL_REPORT.md與results/s28-label-summary.json有完整結果。

## 資料邊界與後續

76700..76747獨立驗證、75400..75463正式仍完全未開啟。
76800..76831已揭曉開發；76900..76907現在是已揭曉訓練／診斷，不能當保留集。
不要用歷史已揭曉final調參；其他邊界沿用PROTOCOL.md。

下一輪先檢查既有研究假設是否仍值得做：有限預算搜尋誤差與根動作成本
不確定性尚未被分離。若沿用標籤方向，應預先處理平手／不確定性與狀態
分布，使用新訓練／診斷集；不能直接把本輪四世界均值當可靠偏好訓練。
也可探索其他決策方式，但不可僅增加預算或模型複雜度。沒有指定下一候選，
沒有宣稱任何尚未測試的方向有效；請自主選擇，事先固定實驗與停止規則。

## 重現

source /workspace/.blockfish-env/activate.sh
python3 research/build.py robust-dag robust-dag-observer public-labels
python3 research/decide_cohort.py --lock research/results/s27-dev-lock.json --inputs research/results/s27-dev.jsonl research/results/s24-control-dev.jsonl --out-prefix research/results/s27-dev --gate mean
python3 research/audit_dag.py research/results/s27-dev.jsonl research/results/s27-observer-parity.jsonl --out research/results/s27-combined-audit.json
python3 research/collect_public_labels.py
python3 research/analyze_public_labels.py

collector按已記錄seed續接，不重跑成功任務；error/timeout不可刪除挑結果。
public-labels --audit FILE只回放；build.py保存二進位SHA與sourcehash。
勿重建覆蓋learned-robust/learned-fast；所有新feature只在指定headless profile測過。
目前仍為本地規則/模擬結果，無官方Jstris榜單超越證據。

--- 以下歷史續接（不是執行中狀態） ---

# 最新S28標籤診斷執行中（2026-11-15）

S27已完成失敗：197.28125 vs196.21875，32/32，CI[-1.71875,3.8125]。
35回放、68tests、observer3盤精確parity通過；不升級、不開76700/75400。
SYNTHESIS_S27.md綜合過去失敗，注意共同代理目標問題並非唯一已證實根因。

S28新訓練來源76900..76907 frozenrobust50k八盤已完成並回放。
固定第100塊後公開狀態，50k提出最多兩根，各四共同公開條件世界。
強策略50k直到完成，另量測同強策略第4步端點、1040弱策略4步端點。
上限64條完整反事實延續、每條400落子，不擴樣本、不訓練模型。
正在 python3 research/collect_public_labels.py，4workers，s28-labels.jsonl。
每source完成後存s28-label-SEED.json（操作／節點），已內建完整重播audit；
collector另核對base第一動作與frozen source第101動作一致。
先查進程勿重複；script可依已記錄seed續接，timeout/error不可丟棄。
完成後 python3 research/analyze_public_labels.py，保存s28-label-summary.json。
新binary public-labels與root-dag皆optional；frozenbest所有檔案未改。

--- 以下S27歷史執行紀錄（目前已完成） ---

# 最新 S27 執行中（2026-11-15）

S11/S26全部manifest hash已核對不變，可靠best仍frozenrobust。
綜合分析與本輪預註冊：SYNTHESIS_S27.md、PROTOCOL.md。
新root-dag保留每根身份，對完整State/depth/root的重複非終點只展開一次；
終點不剪、原parent-f與robust4不改，所有重複節點本身仍計入50k。
68tests通過，包含小棋盤完整窮舉每根評分相同、完整合法路徑與重設表。
3盤76000..2 observer-only對凍結robust完整inputs/ds/counts parity與回放通過。
正在robust-dag32盤76800..31，4workers，s27-dev.jsonl，沿用s24-control-dev.jsonl對照。
observer記錄平均735重複非終點展開／步，但此為3盤描述非品質證據。
完成後以s27-dev-lock.json及s24-control-dev.jsonl執行decide_cohort.py，
再跑audit_dag.py及replay_audit.py；S27候選目前不可升級。
嚴格比平均與完成率，通過才開76700驗證；75400final仍未開。
勿重建覆蓋learned-robust/learned-fast。先查進程與輸出行數勿重複啟動。

--- 以下S26完成紀錄 ---

# 續接狀態：S24–S26 完成（2026-11-14）

## 當前狀態

沒有執行中的實驗。可靠最佳仍為凍結 cheese-robust（learned-robust，50k）。
S11 manifest所有檔案hash不變，見s26-baseline-integrity.json。
本輪165局全部完成並回放，35個seed ID（開發盤重用，不是165個獨立樣本），
2767.110916 CPU秒。見results/s24-s26-completion.json。
完整原始trace、cohort、鎖定manifest、稽核與二進位都留在research/。
源碼與腳本checkpoint：checkpoints/s26-20261114-source.tar.gz 及manifest。

## 結果：32盤開發76800..76831、同50k生成節點

- frozen robust196.21875。
- S24獨立根scout＋sequential halving199.15625；差+2.9375，95%[.0625,5.8125]。
- S25保留25%預算時已評分優勝半數根198.8125；差+2.59375，95%[-.03125,5.1875]。
- S26公開條件世界、短期閉迴路模擬209.96875；差+13.75，95%[11,16.375]。
- S26同工作量placebo198.1875；模擬選擇版比placebo差+11.78125，95%[8.78125,14.90625]。
所有版本32/32完成。三個方向皆拒絕，不升級，不擴樣本救援。
ROOT_SEARCH_REPORT.md、PUBLIC_ROLLOUT_REPORT.md有方法、成本、診斷與重現命令。

## S26實作及稽核

block-stacker/public-world：只從公開盤面/current+5/Hold/七袋歷史/公開垃圾計數與
最後洞重建世界，不接受真實Stacker或真實seed；兩種隨機流domain-separated。
既有SRS、Hold、合法落點、補垃圾沿用。69engine tests、7simulator tests通過。
world_rollout/mod.rs：37.5k基礎搜尋，前2根×2共同世界×4落子；剩餘12.5k包含
每世界根、每模擬落子、全部後續搜尋。正常兩根時每次後續搜索1040節點。
凍結盤面估值/10與原價格2.083984375；不訓練新權重。缺建議截斷，非假死亡。
同工作量placebo仍選原第一名；真實遊戲只執行原合法候選一步。
64dev+2smoke完整回放/public/world audits通過，實際publichistory逐步核對。
world-audit的真實seed只用於重建過去觀察，規劃介面不接受它。

候選17.83%決策改選；68.42%模擬路徑補垃圾；無截斷/topout。
兩世界偏好分歧6.73%，不支持把顯著退步簡化成抽樣雜訊。
額外offline world-diagnostic只讀既有placebo trace，不跑新搜索、不改候選：
第一個後續狀態恰與真實可見盤面/current/preview/Hold相同的3732樣本中，
938（25.13%）的低預算策略結果不同於37.5k策略。相關樣本，不是獨立品質證據。
證明策略落差存在，沒有證明哪個動作較好，也沒有證明提高預算即可修復。

## 尚未使用的資料與接續方向

獨立驗證76700..76747與正式75400..75463仍完全未開啟。
76800..76831是已揭曉開發；舊76000..31亦只可作歷史開發／parity。
其他歷史訓練與保留集邊界見PROTOCOL.md。不要把已揭曉final拿來調參。

目前清楚瓶頸是根動作成本排序可靠性，而不只是模擬速度或節點覆蓋。
停止S24淘汰比例與S26世界數/步數/預算比例掃描。沒有實驗唯一識別誤差根因。
下一輪可先設計新訓練／診斷集上的反事實根動作標籤，使用本輪公開重建
基礎設施、共同隨機數、凍結實際策略延續，檢查策略一致性、排序與標籤
不確定性；之後才決定是否值得訓練。這是尚未執行的方向，不是已驗證方案。
不要只增加部署搜索預算，也不要直接把短期或完整預覽狀態回報當搜尋葉真值。

## 重現入口

source /workspace/.blockfish-env/activate.sh
python3 research/build.py world-rollout world-rollout-placebo world-diagnostic
python3 research/decide_cohort.py --lock research/results/s26-dev-lock.json --inputs research/results/s26-dev.jsonl research/results/s24-control-dev.jsonl --out-prefix research/results/s26-dev --gate mean
python3 research/audit_worlds.py research/results/s26-dev.jsonl --out research/results/s26-world-audit.json
python3 research/diagnose_world_policy.py research/results/s26-dev.jsonl --out research/results/s26-policy-mismatch.json

構建world-diagnostic後新增的Cargo bin定義不改候選邏輯；原候選binary/sourcehash
保留於builds.jsonl。不要重建覆蓋learned-robust或learned-fast。
目前原型只支援headless固定節點研究，不宣稱官方Jstris規則完全一致或榜單紀錄。

--- 以下歷史續接（不是執行中狀態） ---


# 最新：S24新搜尋配置開發測試執行中

最佳cheese-robust凍結保留，S11manifest所有hash驗證未變。
S24 root-halving：獨立每根B*，先各取一條完整延續，再按最新robust評分
逐輪保留ceil-half，分配剩餘生成預算；不改估值、合法落點、Hold、預覽。
所有root枚舉/scout/refine共50k；每step至多1生成。淘汰動作透過新
Step::RemoveMove/Analysis訊息移除，避免留下過期樂觀分數。
67候選tests、66控制tests通過；halving-control3盤76000..2與frozenrobust
完整inputs/ds相同（s24-control-parity-check.json）。只測headless固定節點。

正在新DEVELOPMENT76800..76831，兩版各32，共應64筆：
python3 research/bench.py --binaries research/bin/robust-halving research/bin/learned-robust --configs 50/5,10,10,10 --start 76800 --count 32 --jobs 4 --out research/results/s24-dev.jsonl
先查進程勿重複。完成後：
python3 research/decide_cohort.py --lock research/results/s24-dev-lock.json --inputs research/results/s24-dev.jsonl --out-prefix research/results/s24-dev --gate mean
python3 research/audit_halving.py
python3 research/replay_audit.py research/results/s24-dev.jsonl research/results/s24-control-parity.jsonl --out research/results/s24-replay-audit.json

stderr每步ROOT_ALLOCATION記錄總節點、scout節點、roots、rated_roots、survivors。
不能以覆蓋率代替完整100L方塊數。若平均及完成率通過才開新76700..76747
三版驗證含learned-fast；再通過才開75400..75463正式64，雙控制95%區間全負，
不擴正式樣本。若失敗先看scout是否耗盡預算／評分支持不足，而非微調估值。
76800..76831現在是開發集，76000已反覆使用不再作本輪候選選擇。

以下上輪完整狀態（S20–S23）：

# 研究續接（2026-11-14，S20–S23全部完成）

## 現在狀態

沒有執行中的實驗。最佳仍為cheese-robust（research/bin/learned-robust，50k生成節點）。
原cheese-quality／learned-fast、S11source checkpoint及manifest所有hash核對未變。
S20–S23新增601局全部完成及完整回放，336個不同seed ID（開發seed重用，不能
當601個獨立樣本），8033.862064 CPU秒。見results/s20-s23-completion.json。

## 最新結果

S22正式75300..75363三版各64/64：
- learned-fast 198.671875塊；learned-robust 196.21875；Hold候選196.546875。
- 候選−robust +0.328125，95%[-1.515625,2.15625]，27勝6平31敗。
- 候選−legacy -2.125，95%[-4.25,0]。雙控制嚴格區間門檻失敗，**不升級**。
- 192回放、逐步metadata一致性與50k預算檢查全通過。
- robust−legacy -2.453125，95%[-4.171875,-0.671875]，再次支持既有策略。
- 不擴樣本，不合併開發挽救；正式前已約定僅通過才跑200k，因此未啟動200k。

## 候選由來／保留的失敗實驗

1. S20：新資料76400..76559，160局5k來源，全回放；128訓練76400..76527，
   32預測驗證76528..76559。公開Hold×5盤面特徵，固定ridge10，類型均值零。
   整局成本標籤驗證MSE40.28499→40.32575，未接入策略。
2. S21：同128訓練，固定7步＋凍結估值標籤；新76600..76631預測驗證32局。
   MSE2.735080→2.722706，區間跨零。沒有步數／正則掃描。
   robust-hold-context = cheese-robust + hold-context + preserve-hold。
   32dev198.15625 vs robust197.1875，拒絕。68測試，32回放通過。
3. S22：相同權重、原本耗盡Hold終點；robust-hold-order = cheese-robust
   +hold-context，影響中間估值及parent_f，不能稱純排序。
   dev76000..76031：195.96875 vs197.1875；新驗證76200..76247：196.6875
   vs197.833333，皆CI跨零但通過預設平均篩選；正式未重現，詳見上方。
4. S23：精確cache，robust-hold-cached = cheese-robust + hold-context-cache。
   每analysis盤面cache七種Hold修正，69測試；三盤完整inputs/ds/搜尋計數一致，
   6回放。CPU22.628→20.306秒，RSS26209→30996KiB；僅小型成本試驗。
   沒有減少方塊數，未替換S22正式執行檔，也不作推薦profile。

## 程式與重現

- CONTEXT_REPORT.md、PROTOCOL.md記錄完整假設／門檻／結果，s22-outcomes.svg圖。
- fit_hold.py：不帶參數為S20，--td7為S21；權重不重新選擇。
- 模型blockfish-engine/src/ai/hold_weights.rs；s21-fit-dependencies.json資料hash。
- State.held_color()只回實際Hold，空Hold不能把next().1當Hold。
- hold-context不隱含preserve-hold；S21profile明確加入，S22不加入。
- audit_context_cache.py檢查S23完全等價；diagnose_hold_coverage.py查訓練覆蓋。
- decide_cohort.py含配對seed/hash/config/每步預算/trace一致性門檻；replay_audit.py回放。
- checkpoints/s22-candidate-20261114-source.tar.gz已離線還原建置，二進位SHA與
  凍結S22完全相同（results/s22-restore-check.json）；當時是候選快照，現在正式失敗。
- checkpoints/s23-20261114-source.tar.gz保存本輪完成源碼與腳本；manifest含結果hash。

## 下一步與禁止重用

停止這組Hold殘差的係數／正則／步數／邊界微調。觀察性實際遊戲回報與
搜尋葉分布不同、七步標籤繼承凍結估值偏差，均是限制，尚未證明唯一失敗原因。
可研究少量候選的條件rollout或搜尋葉成本標籤；沿用原SRS/Hold/合法落點。
線上抽樣只能依公開七袋歷史，不可複製真實隱藏RNG後拿來評分。
未實作這些後續方法，不宣稱改善。仍優先完整100L方塊數，不以MSE或速度代替。

76200策略驗證、75300正式已開封；76400..76559與76600..76631已用資料學習。
76000..76031反覆開發，不是泛化證據。未來不同假設可用76700..76747新驗證、
75400..75463新正式，目前尚未使用。S11/S18等先前保留集也不可調參。
舊續接全文CONTINUE_HISTORY_20261114.md僅供歷史，若衝突以本檔及各lock為準。
