# Experiment protocol (2026-11-08)

## Search-allocation continuation

New development cohort 62000..62011; validation 62100..62131; reserve final
62200..62263. Do not reuse prior final seeds for selection. Frozen learned-fast
is the primary control, at 50k cumulative generated nodes, no move deadline.

S1: back up every terminal successor immediately upon generation rather than
queueing it by its intermediate f score. Count every successor as before.
After finishing a parent whose children are all terminal, resume best-first
selection at another nonempty level. This tests terminal-rating coverage and
search allocation, not additional information or an increased node budget.
S2: combine S1 with leaving the last held piece unforced, as a separate ablation.
S3: revisit the previous unique-state beam with the frozen learned evaluator;
previous beam comparisons primarily used the original heuristic. Keep warmup
and all generated successors inside the same budget. Screen all complete races,
then select using validation before opening the new final cohort.

S4: with the unchanged frozen learned evaluator and original B* backup, vary
the per-piece path penalty from 10 to 5 or 20 on the same development cohort.
This changes depth allocation and the cost/value balance, not the node budget
or information. Screen these separately from eager backup before combinations.

Advance S1 alone to the 32 validation seeds at 50k: development mean196.4167
versus196.9167, eleven piece-count ties and one six-piece win. This narrow result
is not sufficient for promotion. Reject S2/S3/S4 from further tuning for now.

S5: paired counterfactual action labels. Frozen learned policy generates 80 games
on 73000..73079 at 5k. At placements20,60,100,140, a 50k frozen search proposes
its best3 distinct root moves. Clone the simulator for each and play to100L with
the frozen 5k policy, sharing the same hidden streams for labels only. Features
are the projected child board BEFORE garbage replenishment, computed from the
public board and legal ghost placement. Neither seed nor hidden future is an
inference input. A failed rollout receives a recorded500-piece penalty; no
failed branch is silently discarded. Retain full operation traces for audit.
Train on64 seeds73000..73063, choose ridge on16 seeds73064..73079. Fit action
feature DIFFERENCES to future-piece DIFFERENCES, regularized toward the frozen
model, with nonnegative board coefficients and fixed prior intercept. Evaluate
full games on62000..62011 before independent validation. No test results train
these weights. This specifically tests whether paired action labels reduce the
irrelevant future-return noise present in previous single-state regression.

S5 deployment screens: use the chosen ranking model alone and a conservative
25% ranking /75% frozen-value mixture on development seeds. The blend fraction
is fixed before full-game results; it is not a runtime use of training futures.
S6: data collection reveals some50k searches completed fewer than3 root moves.
Test one completed preview sequence per root action before global refinement:
while the depth0 heap has an unvisited root, select that level; then resume
original B*. Same value/backup, every expansion charged, no extra previews.
Implementation audit before S6 results: selecting depth0 alone guarantees root
EXPANSION, not completion, because shared deeper heaps can switch ancestry.
Keep this initial ablation as learned-covered (S6a). Add learned-root-complete
(S6b), which temporarily selects only descendants of the active root during its
first rollout, restoring all skipped heap nodes; clear that restriction on
terminal backup. Test both independently on the12 development games.

S7: direct deployment of S5 as a leaf value fails (214.25 vs196.92 pieces);
root-only reranking is a separate, better-matched hypothesis. Keep frozen B*
and learned leaf weights, retain its best3 proposed roots, and learn a residual
cost scorer using both original completed-sequence rating and projected child
features. Train64/model-validate16 on the same offline data, never game test
outcomes. Ridge10/100/1000 and override margin0/1 are selected by mean paired
rollout cost on model-validation games (game weighted equally). Apply only
before80 cleared lines and when all candidate ratings>=20 to exclude the special
bottom-clear rating regime. Reserve3 nodes from the50k search cap and charge each
projection, even though the original search already generated those root boards.
Screen development before validation; never replace the leaf evaluator here.

S8: exact known-preview endgame planning, independently of learned ranking.
When1..4 garbage rows remain and all are visible, spend at most1/5 of the move
budget on A* tracking the exact garbage prefix. Lower bound is ceil(empty cells
in remaining target rows /4); learned value only breaks equal-bound ties. Count
every attempted successor, including duplicates. If a winning known-piece plan
is found, execute the cached plan; otherwise give B* the unspent node budget.
No hidden pieces/garbage enter the solver. No extra per-move budget is granted;
disable this solver for deadline-based runs until a combined deadline exists.
Keep a placebo variant that spends the same planning work but ignores the plan.
First test12 development seeds; no changes to the frozen leaf evaluator.

S8b: the weak endgame bound yields12/12 piece-count ties; the10k budget generally
only finds the last3-placement finish. Strengthen the admissible bound with a
relaxed garbage-hole deletion problem: one move may delete any contiguous run
of up to4 equal hole columns, then remaining rows close up. For dense one-hole
garbage rows, any tetromino crossing multiple such rows must use their same hole
column, so this relaxation includes every legal deletion while ignoring access,
known piece types, and blocking material above. Dynamic programming gives a
lower bound, not a learned estimate. Fall back to empty-cell/4 if rows are not
single-hole garbage. Keep all budgets, activation and fallback unchanged.

Advance S8b to32 validation games: development196.75 vs196.9167, one two-piece
win and11 ties. S8c adds a known-queue/Hold relaxation to the bound: O cannot
fill a single-hole dense garbage row. Compute the minimum placements needed to
use at least the hole-deletion bound's number of non-O pieces, allowing all
other non-O types to act optimistically. Unknown pieces are never added. Keep
the same10k endgame share and test S8c independently before choosing a finalist.

S8d: the last4-row planners mostly match already-optimal short finishes. Apply
the queue-aware planner from at most7 fully visible remaining garbage rows,
still using only the initial current+previews+hold and10k of the50k node cap.
Prune an abstractly impossible root immediately (charged one node). Preserve a
matching wide-placebo budget-control variant. Screen12 development games first;
the reserved final cohort remains unopened.

S9: direct policy optimization, not regression MSE. Freeze training seeds
74000..74031 and5k cumulative nodes. Tune only the six previously nonzero
board coefficients [piece estimate, aggregate height, covered rows, row/column
transitions, wells], each within exp(+/-0.7) of its frozen value; keep bias,
other zero coefficients, search, information, and per-piece cost unchanged.
Six deterministic mirrored hill-climb generations, four Gaussian directions
and their negatives per generation, sigma=max(.08,.25*.8^generation), RNG173.
Every candidate runs ALL32 seeds; rank completion count first, then mean pieces.
The incumbent is retained and results cached by exact weight and binary hashes.
No early stopping on partial means. This is tuning only; a frozen selected
model must pass full50k development and independent validation before final.

## Continuation: budget robustness and policy evaluation (2026-11-09)

All previous final seeds remain sealed against tuning. Diagnose budget response
on fresh seeds 50000..50015, using both frozen quality-baseline and learned-fast,
at 50k and 200k cumulative generated nodes per placement, no time deadline.
This cohort is diagnostic/validation, not the next final test. Keep every run,
including failures; per-game timeout 600 seconds. Concurrent fixed-work runs
may share CPU, so report CPU rather than claiming isolated wall speed.

New hypothesis: fitting costs from the old policy leaves a policy-distribution
mismatch. Collect the frozen learned policy at 5k on fresh seeds 6000..6159;
fit on 6000..6127, choose regularization on 6128..6159, keeping the same board
features and target definition. Compare full games on development seeds 0..11
before any model promotion. Also test learned terminal-only backup separately
from refitting. Reserve seeds 51000..51031 for a subsequent locked final 200k
comparison if a finalist is chosen; never train on these games.

R5: a separate 16-step bootstrapped target on the same policy2 training split:
16 + frozen V(next board) minus the cost of garbage revealed during those steps.
Use the training-only garbage price; validate ridge against Monte Carlo returns
on model-validation games. Do not replace the frozen general-use model unless
full-game validation supports it. No training targets use test-set outcomes.

### High-budget final lock

The central budget-robustness question is evaluated independently of the new
training experiments: freeze original `quality-baseline` and prior `learned-fast`
at 200k cumulative nodes, seeds 51000..51031, 32 paired full games. These exact
binaries are unchanged from the preceding round. Start this test without viewing
R1 aggregate outcomes, and do not inspect its aggregate results until all 64 runs
finish. New R2/R5 models cannot be selected using this cohort; any promotion of
those models requires another untouched test cohort. All runs have a 600-second
per-game timeout, no per-move deadline. Concurrent runs only affect runtime,
not the deterministic fixed-node decisions.

Before inspecting R6 aggregate outcomes (52/64 records present, only completion
counts inspected), add the same two frozen binaries at 50k on the same 32 seeds.
This enables a direct paired budget comparison and a difference-in-differences
estimate, rather than comparing different seed cohorts. This addition is not
conditioned on significance or observed piece counts. Keep both batches whole;
do not extend seed count after unblinding.

R7: the 16-step candidate scores 197.833 versus frozen 198.083 on 12 development
games, an inconclusive 0.25-piece improvement. Freeze its fitted weights and
evaluate all 16 diagnostic seeds 50000..50015 at 200k against the existing R1
frozen-model results. This is validation, not a final promotion test. The policy2
Monte Carlo refit is not advanced after 198.500 on development games.

R8: distinguish clearing currently visible garbage from finishing the race.
Retain residue value after a visible-bottom clear while unseen garbage remains;
keep the old shortest-finish rating when all remaining garbage is visible.
Use only public cleared-line count and visible garbage count, no future holes.
No change to legal placements, queue, or search horizon. First test development
seeds 0..11 at 50k with the frozen evaluator. This differs from the previous
unconditional goal-residue ablation, which also penalized final-race residue.

Upstream commit: `739953f9331b7648f269fc52cff5aae330108ccd`.
Rust 1.75.0, release profile, locked dependencies. Environment has a 4-core
cgroup CPU quota. All 64 upstream workspace unit tests passed before changes.

## Fixed rules and information

Use the upstream block-stacker simulator and SRS placement/finesse infrastructure,
10 columns, 5 previews, current piece and hold; no future garbage or hidden queue
is passed to the AI. Target is **100 garbage rows**, not 100 arbitrary clears.
Explicit `-g 9 -G 4` matches the actual upstream defaults (CLI help incorrectly
claimed 2). Seven-bag and nonrepeating adjacent garbage holes use upstream
Pcg64Mcg. This is a local simulation benchmark, not verified Jstris replay parity.
Piece and garbage generators clone the same initial PRNG: keep that unchanged
for paired comparisons, but note it is not an independently sampled Jstris RNG.

## Splits and budgets

- Development seeds: 0..11. Used for selecting hypotheses and weights.
- Validation seeds: 1000..1023. May be used to decide finalists.
- Locked final test seeds: 10000..10099. Do not tune using their results.
- Any later record hunting must be reported separately from held-out averages.
- Stage 1/2 screening: 5,000 frontier nodes per placement, complete 100L races.
- Confirm at 50,000 (the upstream default), and report cost as well as quality.
- Timeout is a failure, never silently omit it. Completion rate precedes mean
  pieces; means and paired intervals refer to completed runs only.
- Upstream `node_count` is frontier occupancy, not cumulative generated nodes:
  `pop` decrements it. Keep this exact budget for weight/rating/cache comparisons.
  It must not be called an equal total-work or equal-time budget.
- Randomize task order with fixed seed; store command configuration, executable
  SHA256, seed, status, trace, wall time. Compare CPU costs in isolated serial
  runs because concurrent experiments share the quota.

`bench.py` runs real executable processes, preserves errors, supports resume and
records one JSON object per race. `summarize.py` reports paired bootstrap intervals
(10,000 resamples, fixed seed); intervals do not correct for tuning-selection bias.
Raw per-piece clear traces are retained beside JSONL results.

## Hypotheses

1. Lower height penalty may let residue-based piece estimate guide efficiency;
   zero height penalty may cause unstable stacking. Sweep one factor at a time.
2. Exact static-score memoization can avoid evaluating transposed matrices without
   changing legal placements, queue information, search ordering or decisions.
3. Parent+terminal score smoothing may discourage good final placements; test
   terminal-only ratings with identical heuristic and budget.
4. Rewarding only depth after clearing the visible bottom row ignores residual
   stack when more garbage remains; test retaining residue score at that boundary.

Experimental Cargo features `eval-cache`, `terminal-only`, `goal-residue` keep
ablations reproducible. Only exact `flood-eval` + `eval-cache` optimizations are
promoted to defaults; use `--no-default-features` for unoptimized ablations.

## Final evaluation lock

Before opening seeds 10000..10099, freeze original B* rating and weights
`5,10,10,10`. Final candidate changes only the implementation of static evaluation
(bitwise I dependencies, bitset flood fill, exact matrix-score memoization).
Compare instrumented original versus candidate:

- 5k frontier limit, no deadline: 100 paired full races; compare every input and
  every clear trace. Original archived binary is also retained for audit.
- 50ms soft search-worker wall deadline plus 50k frontier cap: 100 paired races,
  interleaved randomly across variants with four workers on a four-core quota.
  No other CPU experiments/builds run during this batch. Report actual worker
  milliseconds and generated nodes; deadlines are checked every 64 steps after
  at least one finished sequence. Timing-mode decisions are not deterministic.
- Test results will not be used to retune weights or choose a different search.

The 50ms validation set includes wide-beam to diagnose deadline robustness,
but that algorithm is excluded from the final candidate after observed top-outs.

## External record verification

README links historical Jstris replays 53445238 and 54532835 but gives no numeric
record. Search finds historical claims of 170 pieces; this is not evidence of
the current strongest record. Direct leaderboard/replay reads through web search
failed. Do not claim a world record without a verified current benchmark and a
legally replayable run under matching rules.

## Quality-first continuation

Following the user's clarification, execution speed is a secondary criterion.
The previous independent timing study is complete: 202.79 versus 202.33 pieces,
paired delta -0.46 with 95% bootstrap interval [-1.94, 1.04]. This does **not**
establish lower piece counts. Keep its 100 seeds separate from subsequent tuning.

New quality experiments use no wall deadline and a fixed cumulative generated
node cap, including warmup, failed branches and duplicates. Original and candidates
all use the same visible information, exact evaluator implementation and simulator.
Development remains seeds 0..11 initially; validation remains 1000..1023, with
additional validation seeds 2000..2063 available if selection needs a larger set.
Reserve **20000..20099** as a fresh final quality test set; do not inspect candidate
performance on it until the strategy is frozen. A minimum-cost record hunt is a
separate activity and cannot replace distribution-level evaluation.

Hypotheses in this phase:
- Stop when only held material remains, rather than forcing the final held piece.
- Rate every completed beam leaf with its terminal score; do not discard it by a
  different intermediate priority.
- Preserve distinct board/queue/hold states in the beam rather than many equivalent
  paths, and test width versus depth allocation at fixed total generated work.
- An available held I piece may cover one I dependency; test this queue-aware
  correction separately from horizon and beam changes.

### Quality finalist lock, 2026-11-09

Validation 1000..1023 selects `learned-fast`, the pure learned value function,
without global transposition pruning or hold-horizon changes. All 24 complete;
197.2083 pieces versus baseline 202.2917; paired delta -5.0833, bootstrap 95%
[-9.0417, -1.5417]. The mixed model is weaker at 198.9167. Freeze weights from
`value-fit.json` (training 3000..3127, model-validation 3128..3159), all search
behavior and parameters before opening quality test seeds 20000..20099.

Final tests on these 100 seeds:
1. 50k cumulative generated nodes, no deadline, baseline versus learned-fast.
2. 50ms per-placement soft worker deadline plus the same 50k generated cap,
   baseline versus learned-fast. Four interleaved workers, no other CPU experiments.
Both batches record completion, pieces, generated nodes, CPU, wall time and peak
RSS. `measure.c` obtains per-process resource usage through wait4. Test outcomes
will not be used to adjust the model or select a different variant.

### Separate local record budget scan

After both final batches finish, scan the frozen learned model on development
seed 3 at cumulative budgets 1k, 2k, 3k, 4k, 5k, 6k, 8k, 10k, 15k, 20k, 30k,
50k. This seed was selected because it previously achieved 178 pieces at 5k.
This is explicitly selected-seed record hunting, not a new independent test or
a basis for selecting the general-use budget. Preserve every result, including
worse runs; replay the complete batch. No model or search changes are allowed.

### S9 frozen candidate validation, 2026-11-10

Training finished all 49 models on seeds74000..74031 at5k. Freeze selected
weights hash00f5e0788d2a693811aa7f6a273e9760948d7c69d00c9f21fe7cb9956ca2a360.
Static learned-direct is compared on development62000..62011 at50k, then
validation62100..62131 at both5k and50k against frozen learned-fast.
No retuning on these results. Reserve final62200..62263 unopened; only promote
a supported candidate after a fresh paired final. Completion precedes pieces;
record CPU costs and paired uncertainty, and report budget-specific failures.

### S10 predeclared shrinkage experiment

S9's 50k development mean198.5 does not improve196.9167. Independently of
unfinished validation, test exactly one regularized candidate: arithmetic
midpoint between frozen prior and S9 weights, unchanged B*,50k, development
62000..62011. Hypothesis: reduce training-specific weight displacement while
retaining useful full-game adjustment. This is development selection, not an
independent performance claim. If worse, reject without opening final seeds.

### S11 structural backup experiment (2026-11-10)

Freeze learned-fast weights and all B* expansion priorities. Compare each root
by mean rating of its best4 DISTINCT terminal states (or all available if fewer),
rather than best single sequence. Deduplicate by complete State, including queue
and Hold. Return best sequence for that root. Permit score increases as support
arrives; preserve exact bottom-goal preference. No extra generated nodes or future
information; runtime/memory overhead recorded. This is a heuristic robustness
hypothesis, not an unbiased expectation or chance-node estimator.
Development62000..62011 at50k. If promising, lock and validate new seeds75000..75047
at50k with freshly interleaved frozen control. No use of62100 or final62200 for
tuning. Test fixed4 once; do not search k on this development sample.

S11 validation lock: development12/12 complete,195.3333 vs196.9167,
paired delta-1.5833 CI[-4.8333,1.9167]. Freeze learned-robust before opening
75000..75047. Run both binaries interleaved,50k generated nodes,48 seeds each.
No parameter or implementation changes based on interim results. Formal final
62200..62263 remains sealed. If validation supports improvement, use the full
predefined64-seed final cohort; no early stopping or sample expansion.

S11 implementation placebo: collect the same4 distinct terminal states but
return their minimum instead of mean, with the same quarter-unit scaling.
Run12 development games; compare complete operation traces to frozen control.
Purpose: isolate averaging from collection overhead, trace handling and score
rescaling. No validation selection based on placebo.

S11 validation gate clarified before inspecting any validation piece counts:
advance to the fixed64-seed final only if completion is no worse and mean pieces
is lower than control. Validation CI is reported even if it spans zero; this is
candidate selection, not proof. Require fresh final evidence before promotion;
never expand the final cohort after viewing its outcomes. No interim comparisons.

S11 final lock: validation48/48 both complete,196.5625 vs197.4791667,
delta-0.9166667 CI[-3.5833333,1.6875]. Gate satisfied on mean, not a proof.
Open all final62200..62263 now, frozen learned-robust versus learned-fast,
50k cumulative generated nodes,4 interleaved workers. No other race experiments
in parallel. Promote only if completion is no worse and the fresh final paired
95% bootstrap interval for candidate-minus-control is wholly below zero.
Otherwise retain as unproven research branch, regardless of pooled results.

S11 budget diagnostic locked before viewing final outcomes: after the50k final,
run both frozen variants at5k on the same48 validation seeds75000..75047.
Compare with existing50k validation for a paired budget interaction. This tests
whether averaging support requires enough completed sequences. It cannot replace
failed final evidence or tune k; do not promote from this exploratory diagnostic.

### S12: coverage with robust backup, 2026-11-13

S11 final passed its predeclared gate; preserve original learned-fast and frozen
learned-robust binaries. Low-budget validation5k is worse in point estimate, not
significant. Hypothesis: average backups require more balanced root evaluation,
whereas forcing root coverage previously hurt minimum backups. Test existing
root-complete (one full preview per root before refinement) with robust-backup.
No retuning of k, weights, budgets, or coverage policy. Development62000..62011,
50k; compare against robust195.3333 and original learned196.9167. If development
improves over robust, validate frozen candidate on new75100..75147; reserve
75200..75263 for a subsequent final only. Never tune on opened62200 final.
