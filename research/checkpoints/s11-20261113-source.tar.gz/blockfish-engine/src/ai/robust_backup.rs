//! Compare roots by several distinct plausible continuations, not one optimistic leaf.
use super::state::State;

#[derive(Default)]
pub(super) struct Leaves(Vec<(State, i64, Vec<usize>, bool)>);

impl Leaves {
    pub fn record(
        &mut self,
        state: State,
        rating: i64,
        trace: Vec<usize>,
        goal: bool,
    ) -> (i64, Vec<usize>) {
        if let Some(old) = self.0.iter_mut().find(|x| x.0 == state) {
            if rating < old.1 {
                *old = (state, rating, trace, goal);
            }
        } else {
            self.0.push((state, rating, trace, goal));
        }
        self.0.sort_by_key(|x| x.1);
        self.0.truncate(4);
        let score = if self.0[0].3 {
            self.0[0].1
        } else {
            // Fixed-point quarter units avoid losing mean-score distinctions.
            self.0.iter().map(|x| x.1).sum::<i64>() * 4 / self.0.len() as i64
        };
        #[cfg(feature = "robust-placebo")]
        let score = if self.0[0].3 {
            self.0[0].1
        } else {
            self.0[0].1 * 4
        };
        (score, self.0[0].2.clone())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{ai::Snapshot, BasicMatrix, Color};
    fn state(c: char) -> State {
        Snapshot {
            matrix: BasicMatrix::with_cols(10),
            hold: None,
            queue: vec![Color::n(c)],
        }
        .into()
    }
    #[test]
    #[cfg(not(feature = "robust-placebo"))]
    fn duplicate_paths_cannot_fake_diverse_support() {
        let mut leaves = Leaves::default();
        assert_eq!(leaves.record(state('I'), 10, vec![0, 1], false).0, 40);
        assert_eq!(leaves.record(state('O'), 30, vec![0, 2], false).0, 80);
        for _ in 0..10 {
            assert_eq!(
                leaves.record(state('I'), 10, vec![0, 3], false),
                (80, vec![0, 1])
            );
        }
        assert_eq!(leaves.record(state('T'), 50, vec![0, 4], false).0, 120);
        assert_eq!(leaves.record(state('L'), 70, vec![0, 5], false).0, 160);
        assert_eq!(leaves.record(state('S'), 90, vec![0, 6], false).0, 160);
        assert_eq!(
            leaves.record(state('O'), 6, vec![0, 7], false),
            (136, vec![0, 7])
        );
    }
    #[test]
    fn exact_completion_retains_shortest_goal_preference() {
        let mut leaves = Leaves::default();
        leaves.record(state('I'), 100, vec![0, 1], false);
        assert_eq!(
            leaves.record(state('O'), 3, vec![0, 2], true),
            (3, vec![0, 2])
        );
    }
}
