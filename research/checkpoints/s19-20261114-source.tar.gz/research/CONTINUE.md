# 最新續接（2026-11-14，S18/S19完成）

最佳仍為cheese-robust，50k生成節點；S11快照與全部凍結二進位hash核對未變。

S18正式75200..75263：推論195.046875、robust placebo195、legacy198.40625，三版64/64。
推論−robust+0.046875 CI[-1.90625,1.953125]，拒絕升級；192回放全部通過。
128局公開歷史稽核3628次推論，3612次後續確認、16次末步僅邏輯核對。
S18開發/驗證/正式均完整，詳見BAG_REPORT.md、s18-final-decision.json、s18-outcomes.svg。
正式75200..75263已開封，禁止調參或擴樣本。observer目前只接race入口。

S19隔離preserve-hold失敗：32盤76000..76031、50k，200.8125 vs197.1875，
差+3.625 CI[0.75,6.5]，10勝5平17敗，皆完成；32回放、65引擎測試通過。
完整序列與根覆蓋增加卻未減少方塊。詳見HOLD_REPORT.md與s19-allocation.json。
候選robust-preserve-hold可重建且保存，不升級。停止邊界微調。

沒有執行中的實驗。新預留76200..76247驗證、75300..75363正式尚未使用。
已開封S17驗證75100、S18驗證76100、S18正式75200不能當新集。
下一步應研究條件葉估值/少量候選rollout或其他基本方法；現有14維估值
看不到Hold種類，改葉邊界卻不改訓練分布可能有問題，但尚無因果證明。
不要因S18推論邏輯正確、S19覆蓋變多就宣稱策略提升。所有選擇看完整100L方塊數。

以下是舊記錄，與上方衝突以上方為準：

# 研究續接狀態（2026-11-13，S11–S15完成）

S16已拒絕：分支強制多樣性32/32敗，232.78125 vs197.1875。
S17分層版開發195.40625 vs197.1875，但新驗證75100..75147：
較早版198.875、穩健版197.75、分層198.1875，皆48/48完成。
相對穩健+0.4375，CI跨零；正式75200未開啟。停止再調平均規則。

S18七袋推論版開發已通過：76000..76031，194.625 vs placebo197.1875，
差−2.5625 CI[-4.84375,-0.375]，皆32/32完成。全部32盤placebo與凍結
基準完整操作一致。64份回放與公開歷史稽核通過：1832次推論、1818次
後續揭露確認、14次最後決策僅邏輯核對。

現在正在NEW76100..76147做三版48盤驗證，共應144筆：
python3 research/bench.py --binaries research/bin/robust-bag research/bin/robust-bag-placebo research/bin/learned-fast --configs 50/5,10,10,10 --start 76100 --count 48 --jobs 4 --out research/results/s18-validation.jsonl
先查進程再續跑。候選已固定，驗證結果尚未看。s18-validation-lock.json含hash。
完成後summary expected-count48、全回放，公開歷史稽核用：
python3 research/audit_bag_observer.py research/results/s18-validation.jsonl --no-parity --out research/results/s18-validation-public-audit.json
此輪不重做placebo凍結操作parity（開發32盤已全核對）；legacy無observer
事件，audit明確列為skipped_non_observer，不能宣稱其也作了歷史稽核。

候選完成率不差且平均同時勝過兩對照才開75200..75263三版64盤正式；
正式對兩控制配對95%區間均全負才升級。不擴大正式樣本。75100已用於S17，
不能再叫獨立驗證。75200仍未使用。

Observer只收公開Color串流：初始current+5，以及每次鎖定後新揭露1顆，
首次空Hold則2顆；剩唯一類型時加入搜尋，placebo觀察但不使用。沒有seed/
RNG/隱藏佇列資訊。僅適用已知從新七袋開局的標準遊戲；不可在未知袋起點
的任意中盤初始化。新增observer由race CLI接線，其他AI客戶端尚未自動接線。
詳見PROTOCOL S18及BAG_REPORT.md。

上一輪狀態：S14/S15新增48局全部完成／回放通過，皆拒絕。
詳見TAIL_REPORT.md：逐葉均勻未知下一顆延伸，以及保留已知Hold的
邊界延伸，平均199.9167／202.0，基準195.3333。不要因其CPU較低
或勝過自身較弱安慰劑而升級。七種枚舉壓縮已知序列搜尋約773→202。
後續需要重新分配精評位置或驗證條件模型，不要繼續微調逐葉延伸。
新推薦：cheese-robust，**每步50k生成節點**。
原cheese-quality / research/bin/learned-fast完整保留為可靠基準。

S11固定估值與B*展開，第一步按最佳4個不同終局平均評分；未訓練新權重。
- 開發12盤195.3333 vs196.9167。
- 新驗證75000..75047，48盤196.5625 vs197.47917，CI跨零。
- **正式62200..62263，64盤196.921875 vs199.15625，差−2.234375，
  95%配對bootstrap[-4.4375,-0.125]，兩版64/64完成，39勝2平23敗。**
  通過事前門檻，保留版本；區間接近零，證據只限此模擬器50k預算。
- 同驗證集5k：204.3958 vs202.5，差+1.8958，CI跨零；不推薦低預算。
- 安慰劑12盤與基準完整操作一致。新profile3盤與凍結候選完整操作一致。

S12 robust+root-complete：開發197.0 vs robust195.3333，拒絕。
S13 robust+endgame-wide：開發12/12同方塊數，195.3333，拒絕。
目前不要再調k、重複根覆蓋或收尾閾值以尋找開發收益。
預覽邊界已試S14/S15，失敗細節見TAIL_REPORT.md；更根本的候選級精評
或條件模型仍未實作／驗證。亦可增加獨立訓練種子及模型選擇集。

- 371局全完成與全回放通過，124個獨立seed，詳見s11-s13-completion.json。
- GENERALIZATION_REPORT.md完整論證、結果、圖與指令。
- audit_s11_final.py可重現正式預算／hash／seed／回放與升級判定。
- research/checkpoints/s11-20261113-source.tar.gz保存已實際解壓編譯的
  源碼快照；同名manifest.json含hash。使用race,cheese-robust，其他
  optional研究flags不屬於推薦版本。research/bin/learned-robust是凍結
  正式候選；research/bin/cheese-robust是相容profile建置。
- 62200..62263正式集已使用完，不再用於調參；75100..75147新驗證、
  75200..75263新正式仍未開啟。
- 原Jstris規則／RNG未完全核對，不能宣稱官方紀錄。

前輪S9/S10失敗：32訓練種子上49次選擇，訓練−7.53、獨立+2.22。
六盤貢獻70.5%訓練淨收益；不要把1568重跑局數當獨立樣本數。
診斷腳本diagnose_generalization.py保存描述性結果，不宣稱唯一因果根因。
